package com.filtro.filtropalabras;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class FiltroPalabrasAspect {
    private final FiltroPalabrasService filtroPalabrasService;

    public FiltroPalabrasAspect(FiltroPalabrasService filtroPalabrasService) {
        this.filtroPalabrasService = filtroPalabrasService;
    }

    @Around("execution(* com.filtro.FiltroPalabras.FiltroPalabrasController.*(..))")
    public Object filtrarMensaje(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        for (int i = 0; i < args.length; i++) {
            if (args[i] instanceof String) {
                args[i] = filtroPalabrasService.filtrarMensaje((String) args[i]);
            }
        }
        return joinPoint.proceed(args);
    }

}