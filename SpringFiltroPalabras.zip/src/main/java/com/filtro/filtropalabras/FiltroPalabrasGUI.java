package com.filtro.filtropalabras;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;

@Component
public class FiltroPalabrasGUI {
    private final FiltroPalabrasService filtroPalabrasService;

    @Autowired
    public FiltroPalabrasGUI(FiltroPalabrasService filtroPalabrasService) {
        this.filtroPalabrasService = filtroPalabrasService;

        // Verificar si el entorno es "headless" (sin GUI)
        if (!GraphicsEnvironment.isHeadless()) {
            SwingUtilities.invokeLater(this::createGUI);
        } else {
            System.out.println("Entorno sin GUI detectado, la interfaz no se iniciará.");
        }
    }

    private void createGUI() {
        JFrame frame = new JFrame("Filtro de Palabras");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        JTextArea textArea = new JTextArea(5, 30);
        JButton button = new JButton("Filtrar");
        JLabel resultLabel = new JLabel("Mensaje filtrado: ");

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String mensaje = textArea.getText();
                String filtrado = filtroPalabrasService.filtrarMensaje(mensaje);
                resultLabel.setText("Mensaje filtrado: " + filtrado);
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JScrollPane(textArea));
        panel.add(button);
        panel.add(resultLabel);

        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);
    }
}
