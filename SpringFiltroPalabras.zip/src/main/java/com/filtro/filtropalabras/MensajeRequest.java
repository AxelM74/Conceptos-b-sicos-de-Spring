package com.filtro.filtropalabras;

public class MensajeRequest {
    private String mensaje;

    // Constructor vacío requerido por Spring
    public MensajeRequest() {}

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
