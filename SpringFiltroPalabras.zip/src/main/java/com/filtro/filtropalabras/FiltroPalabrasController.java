package com.filtro.filtropalabras;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

@RestController
@RequestMapping("/mensajes")
public class FiltroPalabrasController {
    private final FiltroPalabrasService filtroPalabrasService;

    @Autowired
    public FiltroPalabrasController(FiltroPalabrasService filtroPalabrasService) {
        this.filtroPalabrasService = filtroPalabrasService;
    }

    @GetMapping("/filtrar")
    public String filtrarMensaje(@RequestParam(required = false, defaultValue = "Mensaje vacío") String mensaje) {
        return filtroPalabrasService.filtrarMensaje(mensaje);
    }

    @GetMapping("/test")
    public String test() {
        return "El servidor está funcionando correctamente.";
    }
}
