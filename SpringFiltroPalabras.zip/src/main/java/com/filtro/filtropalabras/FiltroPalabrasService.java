package com.filtro.filtropalabras;

import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;

@Service
public class FiltroPalabrasService {
    private final List<String> palabrasProhibidas = Arrays.asList("malo", "feo", "tonto", "nazi", "gordo", "puto", "naco", "uriel", "zorrita" , "putito" , "estupido", "idiota", "estúpido", "imbécil", "tonto", "pendejo", "baboso", "zoquete", "tarado", "retrasado", "gilipollas",
            "cabrón", "bastardo", "malnacido", "perro", "soplapollas", "comemierda", "vrg" , "verga" , "marica" , "pene", "maricon", "huevon", "pito", "chingada", "chingado", "coño", "verga", "chinga", "joder", "follar", "mamón", "culiar", "paja", "puta", "zorra", "cachondo", "negro", "indio", "sudaca", "cholo", "panchito", "gitano", "maricón", "traba", "putazo", "tortillera", "joto", "hijo de puta", "marimacho");

    public String filtrarMensaje(String mensaje) {
        int contador = 0;
        String[] palabras = mensaje.split(" ");
        for (int i = 0; i < palabras.length; i++) {
            if (palabrasProhibidas.contains(palabras[i].toLowerCase())) {
                contador++;
                palabras[i] = "***";
            }
        }
        return contador > 3 ? "[Mensaje bloqueado por lenguaje inapropiado]" : String.join(" ", palabras);
    }
}
