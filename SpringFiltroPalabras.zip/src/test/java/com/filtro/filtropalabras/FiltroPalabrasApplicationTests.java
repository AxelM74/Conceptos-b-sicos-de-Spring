package com.filtro.filtropalabras;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiltroPalabrasApplicationTests {

	@Test
	void contextLoads() {
	}

}
